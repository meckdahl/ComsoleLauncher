"""
Core functionality for Comsol Project Manager
"""
from .project_scanner import ProjectScanner

__all__ = ['ProjectScanner']
